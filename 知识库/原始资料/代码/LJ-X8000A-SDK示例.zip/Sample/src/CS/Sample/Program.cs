﻿//----------------------------------------------------------------------------- 
// <copyright file="Program.cs" company="KEYENCE">
//	 Copyright (c) 2019 KEYENCE CORPORATION. All rights reserved.
// </copyright>
//----------------------------------------------------------------------------- 
using System;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;

namespace LJX8_DllSampleAll
{
	static class Program
	{
		private static readonly string APPLICATION_CULTURE_NAME = "en-US";

		/// <summary>
		/// This is the application's main entry point.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Thread.CurrentThread.CurrentCulture = new CultureInfo(APPLICATION_CULTURE_NAME);
			Thread.CurrentThread.CurrentUICulture = new CultureInfo(APPLICATION_CULTURE_NAME);
			Application.Run(new MainForm());
		}
	}
}
